document.getElementById('profesorForm').addEventListener('submit', function (event) {
    event.preventDefault(); // Evita el envío del formulario predeterminado

    const profesor = {
        cod_p: document.getElementById('cod_p').value,
        nom_p: document.getElementById('nom_p').value,
        dir_p: document.getElementById('dir_p').value,
        tel_p: document.getElementById('tel_p').value,
        profecion: document.getElementById('profecion').value,
    };

    // Mostrar mensaje de éxito
    alert('¡El formulario se ha enviado correctamente!');

    // Enviar los datos al servidor
    fetch('http://localhost:3000/profesores', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(profesor),
    })
    .then(response => response.json())
    .then(data => console.log(data))
    .catch((error) => console.error('Error:', error));
});
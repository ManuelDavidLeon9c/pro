import express,{Request,Response} from 'express';
import* as profesoresController from '../controllers/profesoresControler';
import {Profesor} from '../model/profesoresmodel';
import { db } from '../../db';
const profesoresRouter = express.Router();

profesoresRouter.post('/', async (req: Request, res: Response) => {
    const newProfesores: Profesor = req.body;
    profesoresController.create(newProfesores, (err: Error, result: any) => {
        if (err) {
            return res.status(500).json({ 'message': err.message });
        }
        res.status(result.statusCode).json(result);
    });
});
profesoresRouter.get('/', async (req: Request, res: Response) => {
    profesoresController.getAll((err: Error, result: any) => {
        if (err) {
            return res.status(500).json({ 'message': err.message });
        }
 
        res.status(result.statusCode).json(result);
    });
});
profesoresRouter.get('/:cod_p', async (req: Request, res: Response) => {
    const cod_p = parseInt(req.params.cod_p);
    profesoresController.getById(cod_p, (err: Error, result: any) => {
        if (err) {
            return res.status(500).json({ 'message': err.message });
        }
 
        if (!result) {
            return res.status(404).json({ 'message': 'Profesor no encontrado' });
        }
 
        res.status(result.statusCode).json(result);
    });
});
profesoresRouter.put('/:cod_p', async (req: Request, res: Response) => {
    const cod_p = parseInt(req.params.cod_p);
    const updatedProfesores: Profesor = { ...req.body, cod_p };
 
    profesoresController.update(updatedProfesores, (err: Error, result: any) => {
        if (err) {
            return res.status(500).json({ 'message': err.message });
        }
 
        res.status(result.statusCode).json(result);
    });
});
 
profesoresRouter.delete('/:cod_p', async (req: Request, res: Response) => {
    const cod_p = parseInt(req.params.cod_p);
 
    profesoresController.remove(cod_p, (err: Error, result: any) => {
        if (err) {
        
            return res.status(500).json({ 'message': err.message });
        }
 
        res.status(result.statusCode).json(result);
    });
});

db.connect((err) => {
    if (err) {
        console.log('Database connection error');
    }
    else {
        console.log('Database Connected');
    }
})
export{profesoresRouter};
export{db};
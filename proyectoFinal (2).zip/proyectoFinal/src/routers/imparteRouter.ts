import express,{Request,Response} from 'express';
import* as imparteController from '../controllers/imparteControler';
import {Imparte} from '../model/impartemodel';
import { db } from '../../db';
const imparteRouter = express.Router();
imparteRouter.post('/', async (req: Request, res: Response) => {
    const newimparte: Imparte = req.body;
    imparteController.create(newimparte, (err: Error, result: any) => {
        if (err) {
            return res.status(500).json({ 'message': err.message });
        }
        res.status(result.statusCode).json(result);
    });
});
imparteRouter.get('/', async (req: Request, res: Response) => {
    imparteController.getAll((err: Error, result: any) => {
        if (err) {
            return res.status(500).json({ 'message': err.message });
        }
 
        res.status(result.statusCode).json(result);
    });
});
imparteRouter.get('/:cod_p', async (req: Request, res: Response) => {
    const cod_p = parseInt(req.params.cod_e);
    imparteController.getById(cod_p, (err: Error, result: any) => {
        if (err) {
            return res.status(500).json({ 'message': err.message });
        }
 
        if (!result) {
            return res.status(404).json({ 'message': 'Estudiante no encontrado' });
        }
 
        res.status(result.statusCode).json(result);
    });
});

imparteRouter.put('/:cod_p', async (req: Request, res: Response) => {
    const cod_p = parseInt(req.params.cod_e);
    const updatedimparte: Imparte = { ...req.body, cod_p };
 
    imparteController.update(updatedimparte, (err: Error, result: any) => {
        if (err) {
            return res.status(500).json({ 'message': err.message });
        }
 
        res.status(result.statusCode).json(result);
    });
});
 
imparteRouter.delete('/:cod_p', async (req: Request, res: Response) => {
    const cod_p = parseInt(req.params.cod_p);
 
    imparteController.remove(cod_p, (err: Error, result: any) => {
        if (err) {
        
            return res.status(500).json({ 'message': err.message });
        }
 
        res.status(result.statusCode).json(result);
    });
});
db.connect((err) => {
    if (err) {
        console.log('Database connection error');
    }
    else {
        console.log('Database Connected');
    }
})

export{imparteRouter};
export{db};
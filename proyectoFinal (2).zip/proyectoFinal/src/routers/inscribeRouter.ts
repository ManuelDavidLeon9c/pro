import express,{Request,Response} from 'express';
import* as inscribeControler from '../controllers/inscribeControler';
import {Inscribe} from '../model/inscribemodel';
import { db } from '../../db';
const inscribeRouter = express.Router();
inscribeRouter.post('/', async (req: Request, res: Response) => {
    const newInscribe: Inscribe = req.body;
    inscribeControler.create(newInscribe, (err: Error, result: any) => {
        if (err) {
            return res.status(500).json({ 'message': err.message });
        }
        res.status(result.statusCode).json(result);
    });
});
inscribeRouter.get('/', async (req: Request, res: Response) => {
    inscribeControler.getAll((err: Error, result: any) => {
        if (err) {
            return res.status(500).json({ 'message': err.message });
        }
 
        res.status(result.statusCode).json(result);
    });
});
inscribeRouter.get('/:grupo', async (req: Request, res: Response) => {
    const cod_e = parseInt(req.params.cod_e);
    inscribeControler.getById(cod_e, (err: Error, result: any) => {
        if (err) {
            return res.status(500).json({ 'message': err.message });
        }
 
        if (!result) {
            return res.status(404).json({ 'message': 'inscripcion no encontrada' });
        }
 
        res.status(result.statusCode).json(result);
    });
});
inscribeRouter.put('/:cod_e', async (req: Request, res: Response) => {
    const cod_e = parseInt(req.params.cod_e);
    const updatedInscribe: Inscribe = { ...req.body, cod_e };
 
    inscribeControler.update(updatedInscribe, (err: Error, result: any) => {
        if (err) {
            return res.status(500).json({ 'message': err.message });
        }
 
        res.status(result.statusCode).json(result);
    });
});
 
inscribeRouter.delete('/:cod_e', async (req: Request, res: Response) => {
    const cod_e = parseInt(req.params.cod_e);
 
    inscribeControler.remove(cod_e, (err: Error, result: any) => {
        if (err) {
        
            return res.status(500).json({ 'message': err.message });
        }
 
        res.status(result.statusCode).json(result);
    });
});
db.connect((err) => {
    if (err) {
        console.log('Database connection error');
    }
    else {
        console.log('Database Connected');
    }
})

export{inscribeRouter};
export{db};
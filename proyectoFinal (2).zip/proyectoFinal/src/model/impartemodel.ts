export interface Imparte {
    cod_p: number;      
    cod_a: number;      
    grupo: number;      
    horario: string;    
}
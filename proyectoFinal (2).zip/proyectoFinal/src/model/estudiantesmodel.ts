export interface Estudiante {
    cod_e: number;
    nom_e: string;
    dir_e: string;
    tel_e: number;
    fech_nac: Date;
}

export interface asignatura{
    cod_a: number
    nom_a: string
    creditos: number
    int_h: number
}
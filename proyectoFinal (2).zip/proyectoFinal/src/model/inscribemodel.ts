export interface Inscribe {
    cod_e: number;      
    cod_a: number;      
    cod_p: number;      
    grupo: number;      
    n1: number;        
    n2: number;        
    n3: number;        
}
export interface Profesor {
    cod_p: number;
    nom_p: string;
    dir_p: string;
    tel_p: number;
    profecion:string;
}
import { Profesor } from '../model/profesoresmodel';
import { db } from '../../db';
import { OkPacket, RowDataPacket } from 'mysql2';
 
export const create = (profesor: Profesor, callback: Function) => {
    const queryString = 'INSERT INTO profesores (cod_p, nom_p,dir_p,tel_p,profecion ) VALUES (?, ?, ?, ?, ?)';
 
    db.query(
        queryString,
        [profesor.cod_p, profesor.nom_p, profesor.dir_p, profesor.tel_p, profesor.profecion],
        (err) => {
            if (err) { callback(err); }
 
            callback(null, {
                statusCode: 201,
                message: '  Profesor creado exitosamente',
                data: {
                    cod_p: profesor.cod_p
                }
            });
        }
    );
};
export const remove = (id: number, callback: Function) => {
    const queryString = 'DELETE FROM profesores WHERE cod_p = ?';

    db.query(queryString, [id], (err, result: OkPacket) => {
        if (err) {
            return callback(err);
        }

        if (result.affectedRows === 0) {
            return callback(null, {
                statusCode: 404,
                message: 'Profesor no encontrado',
            });
        }

        callback(null, {
            statusCode: 201, 
            message: 'Profesor eliminado exitosamente',
        });
    });
};
export const getAll = (callback: Function) => {
    const queryString = 'SELECT * FROM profesores';
   
    db.query(queryString, (err, result) => {
        if (err) { callback(err); }
       
        const rows = <RowDataPacket[]>result;
        const profesor: Profesor[] = [];
        rows.forEach(row => {
            const profesores: Profesor = {
                cod_p: row.cod_p,
                nom_p: row.nom_p,
                dir_p: row.dir_p,
                tel_p: row.tel_p,
                profecion: row.profecion
            };
            profesor.push(profesores);
        });
        callback(null, {
            statusCode: 200,
            message: 'Profesores obtenidos exitosamente',
            data: profesor
        });
    });
};
 
export const getById = (cod_p: number, callback: Function) => {
    const queryString = 'SELECT * FROM profesores WHERE cod_p = ?';
 
    db.query(queryString, [cod_p], (err, result) => {
        if (err) { callback(err); }
 
        const row = (<RowDataPacket[]>result)[0];
        if (row) {
            const profesor: Profesor = {
                cod_p: row.cod_p,
                nom_p: row.nom_p,
                dir_p: row.dir_p,
                tel_p: row.tel_p,
                profecion: row.profecion
            };
            callback(null, {
                statusCode: 200,
                message: 'Profesor obtenido exitosamente',
                data: profesor
            });
        } else {
            callback(null, {
                statusCode: 404,
                message: 'Profesor no encontrado'
            });
        }
    });
};
 
export const update = (profesor: Profesor, callback: Function) => {
    const queryString = 'UPDATE profesores SET nom_p = ?, dir_p = ?, tel_p = ?, profecion = ? WHERE cod_p = ?';
 
    db.query(
        queryString,
        [profesor.nom_p, profesor.dir_p, profesor.tel_p, profesor.profecion, profesor.cod_p],
        (err) => {
            if (err) { callback(err); }
 
            callback(null, {
                statusCode: 200,
                message: 'Profesor actualizado exitosamente',
                data: {
                    cod_p: profesor.cod_p
                }
            });
        }
    );
};
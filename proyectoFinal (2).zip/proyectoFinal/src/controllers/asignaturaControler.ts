import { asignatura } from '../model/asignaturamodel';
import { db } from '../../db';
import { OkPacket, RowDataPacket } from 'mysql2';
export const create = (asignatura: asignatura, callback: Function) => {
    const queryString = 'INSERT INTO asignaturas (cod_a, nom_a, int_h, creditos) VALUES (?, ?, ?, ?)';
 db.query(
        queryString,
             [asignatura.cod_a, asignatura.nom_a, asignatura.int_h, asignatura.creditos],
                (err) => {
            if (err) { callback(err); }
    callback(null, {
                statusCode: 201,
                message: 'Asignatura a sido creada exitosamente',
                data: {
                    cod_a: asignatura.cod_a
            }
    });
 }
);
};

export const remove = (id: number, callback: Function) => {
    const queryString = 'DELETE FROM asignaturas WHERE cod_a = ?';

    db.query(queryString, [id], (err, result: OkPacket) => {
        if (err) {
            return callback(err);
        }

        if (result.affectedRows === 0) {
            return callback(null, {
                statusCode: 404,
                message: 'Asignatura no encontrado',
            });
        }

        callback(null, {
            statusCode: 200, 
            message: 'Asignatura eliminado exitosamente',
        });
    });
};
export const getAll = (callback: Function) => {
    const queryString = 'SELECT * FROM asignaturas';
   
    db.query(queryString, (err, result) => {
        if (err) { callback(err); }
       
        const rows = <RowDataPacket[]>result;
        const asignatura: asignatura[] = [];
        rows.forEach(row => {
            const asignaturas: asignatura = {
                cod_a: row.cod_a,
                nom_a: row.nom_a,
                creditos: row.creditos,
                int_h: row.int_h,
            };
            asignatura.push(asignaturas);
        });
        callback(null, {
            statusCode: 200,
            message: 'Asignatura obtenidos exitosamente',
            data: asignatura
        });
    });
};
 
export const getById = (cod_a: number, callback: Function) => {
    const queryString = 'SELECT * FROM asignaturas WHERE cod_a = ?';
 
    db.query(queryString, [cod_a], (err, result) => {
        if (err) { callback(err); }
 
        const row = (<RowDataPacket[]>result)[0];
        if (row) {
            const asignatura: asignatura = {
                cod_a: row.cod_a,
                nom_a: row.nom_a,
                creditos: row.creditos,
                int_h: row.int_h,
            };
            callback(null, {
                statusCode: 200,
                message: 'Asignarura obtenido exitosamente',
                data: asignatura
            });
        } else {
            callback(null, {
                statusCode: 404,
                message: 'Asignatura no encontrado'
            });
        }
    });
};
 
export const update = (asignatura: asignatura, callback: Function) => {
    const queryString = 'UPDATE asignaturas SET cod_a = ?, nom_a = ?, int_h = ?, creditos = ? WHERE cod_a = ?';
 
    db.query(
        queryString,
        [asignatura.cod_a, asignatura.nom_a, asignatura.creditos, asignatura.int_h],
        (err) => {
            if (err) { callback(err); }
 
            callback(null, {
                statusCode: 200,
                message: 'Asignatura actualizado exitosamente',
                data: {
                    cod_a: asignatura.cod_a
                }
            });
        }
    );
};
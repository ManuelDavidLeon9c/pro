import { Inscribe } from '../model/inscribemodel';
import { db } from '../../db';
import { OkPacket, RowDataPacket } from 'mysql2';
import e from 'express';
 
export const create = (inscribe: Inscribe, callback: Function) => {
    const queryString = 'INSERT INTO inscribe (cod_p, cod_a, grupo, cod_e, n1, n2, n3) VALUES (?, ?, ?, ?, ?,?,?)';
 
    db.query(
        queryString,
        [inscribe.cod_p, inscribe.cod_a, inscribe.grupo, inscribe.cod_e, inscribe.n1, inscribe.n2, inscribe.n3,],
        (err) => {
        if (err) { callback(err); }
 
            callback(null, {
                statusCode: 201,
                message: 'inscripcion creada exitosamente',
                data: {
                    grupo: inscribe.grupo
                }
            });
        }
    );
};
export const remove = (id: number, callback: Function) => {
    const queryString = 'DELETE FROM inscribe WHERE grupo = ?';

    db.query(queryString, [id], (err, result: OkPacket) => {
        if (err) {
            return callback(err);
        }

        if (result.affectedRows === 0) {
            return callback(null, {
                statusCode: 404,
                message: 'inscripcion no encontrado',
            });
        }

        callback(null, {
            statusCode: 200, 
            message: 'inscripcion eliminada exitosamente',
        });
    });
};
export const getAll = (callback: Function) => {
    const queryString = 'SELECT * FROM inscribe';
   
    db.query(queryString, (err, result) => {
        if (err) { callback(err); }
       
        const rows = <RowDataPacket[]>result;
        const inscripciones: Inscribe[] = [];
        rows.forEach(row => {
            const inscribe: Inscribe = {
                cod_p: row.cod_p,
                cod_a: row.cod_a,
                grupo: row.grupo,
                cod_e: row.cod_e,
                n1: row.n1,
                n2: row.n2,
                n3: row.n3
            };
            inscripciones.push(inscribe);
        });
        callback(null, {
            statusCode: 200,
            message: 'inscripciones obtenidos exitosamente',
            data: inscripciones
        });
    });
};
 
export const getById = (cod_e: number, callback: Function) => {
    const queryString = 'SELECT * FROM inscribe WHERE grupo = ?';
 
    db.query(queryString, [cod_e], (err, result) => {
        if (err) { callback(err); }
 
        const row = (<RowDataPacket[]>result)[0];
        if (row) {
            const inscribe: Inscribe = {
                cod_p: row.cod_p,
                cod_a: row.cod_a,
                grupo: row.grupo,
                cod_e: row.cod_e,
                n1: row.n1,
                n2: row.n2,
                n3: row.n3
            };
            callback(null, {
                statusCode: 200,
                message: 'inscripcion obtenida exitosamente',
                data: inscribe
            });
        } else {
            callback(null, {
                statusCode: 404,
                message: 'inscripcion no encontrado'
            });
        }
    });
};
 
export const update = (inscribe: Inscribe, callback: Function) => {
    const queryString = 'UPDATE inscribe SET cod_p = ?, cod_a = ?, grupo = ?, cod_e = ?, n1 = ?, n2 = ?, n3 = ? WHERE grupo = ?';
 
    db.query(
        queryString,
        [inscribe.cod_p, inscribe.cod_a, inscribe.grupo, inscribe.cod_a, inscribe.n1, inscribe.n2, inscribe.n3],
        (err) => {
            if (err) { callback(err); }
 
            callback(null, {
                statusCode: 200,
                message: 'Estudiante actualizado exitosamente',
                data: {
                    grupo: inscribe.grupo
                }
            });
        }
    );
};